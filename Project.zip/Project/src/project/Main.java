
package project;

import java.time.LocalDate;
import java.util.Scanner;

/**
 *
 * @author korisnik
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
   /*  Farma f = new Farma();
Zivotinje z  = new Zivotinje();

        f.UcitajFarmu();
        System.out.println("");
        f.PrikaziFarmu();
        System.out.println("");
        f.DodajFarmu();
        
        System.out.println("");
        
        z.ucitajZivotinju();
        System.out.println("");
        z.prizaziZivotinju();
        
        System.out.println("");
      
        Usevi kukuruz = new Usevi("Kukuruz", LocalDate.of(2024, 4, 15), LocalDate.of(2024, 10, 1), "dobro", 5000);
        Usevi pšenica = new Usevi("Pšenica", LocalDate.of(2024, 9, 1), LocalDate.of(2025, 7, 1), "dobro", 3000);

        // Upravljanje usevima
        UsevManager upravljanje = new UsevManager();
        upravljanje.dodajUsev(kukuruz);
        upravljanje.dodajUsev(pšenica);

        // Prikazivanje svih useva
        System.out.println("Lista svih useva:");
        upravljanje.prikaziUseve();

        // Ažuriranje zdravlja i prinosa
        upravljanje.azurirajZdravlje("Kukuruz", "loše");
        upravljanje.azurirajPrinos("Pšenica", 3500);

        // Prikazivanje useva prema imenu
        System.out.println("Prikazivanje kukuruza:");
        upravljanje.prikaziUsevPremaNazivu("Kukuruz");
        */ System.out.println("");
        Radnik r = new Radnik();
        r.ucitajOsobu();
        System.out.println("");
        r.prikaziOsobu();
       
        System.out.println("");

      Zadatak zadatak = new Zadatak();
      zadatak.ucitajOsobu();
        System.out.println("");
      zadatak.prikaziOsobu();
        
     
        
        
      
        
    }
}


    

        
        